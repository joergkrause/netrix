﻿namespace GuruComponents.Demo.MiniDemo {
    partial class MainForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
      GuruComponents.Netrix.NetrixServiceProvider netrixServiceProvider2 = new GuruComponents.Netrix.NetrixServiceProvider();
      this.menuStrip1 = new System.Windows.Forms.MenuStrip();
      this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
      this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.issuesTestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.loadMailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.insertHTMLAtIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.htmlEditor1 = new GuruComponents.Netrix.HtmlEditor();
      this.speller1 = new GuruComponents.Netrix.SpellChecker.Speller(this.components);
      this.speller2 = new GuruComponents.Netrix.SpellChecker.Speller(this.components);
      this.helpLine1 = new GuruComponents.Netrix.HelpLine.HelpLine(this.components);
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.checkBoxImm = new System.Windows.Forms.CheckBox();
      this.menuStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // menuStrip1
      // 
      this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.issuesTestToolStripMenuItem});
      this.menuStrip1.Location = new System.Drawing.Point(0, 0);
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.Size = new System.Drawing.Size(740, 24);
      this.menuStrip1.TabIndex = 0;
      this.menuStrip1.Text = "menuStrip1";
      // 
      // fileToolStripMenuItem
      // 
      this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
      this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
      this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
      this.fileToolStripMenuItem.Text = "&File";
      // 
      // newToolStripMenuItem
      // 
      this.newToolStripMenuItem.Name = "newToolStripMenuItem";
      this.newToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.newToolStripMenuItem.Text = "&New";
      this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
      // 
      // saveToolStripMenuItem
      // 
      this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
      this.saveToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.saveToolStripMenuItem.Text = "&Save";
      this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
      // 
      // toolStripMenuItem1
      // 
      this.toolStripMenuItem1.Name = "toolStripMenuItem1";
      this.toolStripMenuItem1.Size = new System.Drawing.Size(100, 6);
      // 
      // exitToolStripMenuItem
      // 
      this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
      this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.exitToolStripMenuItem.Text = "E&xit";
      this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
      // 
      // issuesTestToolStripMenuItem
      // 
      this.issuesTestToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadMailToolStripMenuItem,
            this.insertHTMLAtIDToolStripMenuItem});
      this.issuesTestToolStripMenuItem.Name = "issuesTestToolStripMenuItem";
      this.issuesTestToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
      this.issuesTestToolStripMenuItem.Text = "&Issues Test";
      // 
      // loadMailToolStripMenuItem
      // 
      this.loadMailToolStripMenuItem.Name = "loadMailToolStripMenuItem";
      this.loadMailToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
      this.loadMailToolStripMenuItem.Text = "&Load Mail";
      this.loadMailToolStripMenuItem.Click += new System.EventHandler(this.loadMailToolStripMenuItem_Click);
      // 
      // insertHTMLAtIDToolStripMenuItem
      // 
      this.insertHTMLAtIDToolStripMenuItem.Name = "insertHTMLAtIDToolStripMenuItem";
      this.insertHTMLAtIDToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
      this.insertHTMLAtIDToolStripMenuItem.Text = "Insert &HTML at ID";
      this.insertHTMLAtIDToolStripMenuItem.Click += new System.EventHandler(this.insertHTMLAtIDToolStripMenuItem_Click);
      // 
      // htmlEditor1
      // 
      this.htmlEditor1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.htmlEditor1.BackColor = System.Drawing.SystemColors.Info;
      this.htmlEditor1.DockToolbar = System.Windows.Forms.DockStyle.Top;
      this.htmlEditor1.HtmlFormatterOptions = ((GuruComponents.Netrix.HtmlFormatting.IHtmlFormatterOptions)(resources.GetObject("htmlEditor1.HtmlFormatterOptions")));
      this.htmlEditor1.IsFileBasedDocument = false;
      this.htmlEditor1.Location = new System.Drawing.Point(35, 76);
      this.htmlEditor1.MenuStripVisible = false;
      this.htmlEditor1.Name = "htmlEditor1";
      this.htmlEditor1.Proxy = null;
      this.htmlEditor1.ServiceProvider = netrixServiceProvider2;
      this.htmlEditor1.ShowHorizontalRuler = false;
      this.htmlEditor1.ShowVerticalRuler = false;
      this.htmlEditor1.Size = new System.Drawing.Size(689, 385);
      this.htmlEditor1.StatusStripVisible = false;
      this.htmlEditor1.TabIndex = 1;
      this.htmlEditor1.TempFile = "";
      this.htmlEditor1.ToolbarVisible = false;
      this.htmlEditor1.UserAgent = null;
      // 
      // textBox1
      // 
      this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.textBox1.Location = new System.Drawing.Point(111, 37);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new System.Drawing.Size(434, 20);
      this.textBox1.TabIndex = 2;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(20, 40);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(60, 13);
      this.label1.TabIndex = 3;
      this.label1.Text = "&Focus Test";
      // 
      // checkBoxImm
      // 
      this.checkBoxImm.AutoSize = true;
      this.checkBoxImm.Location = new System.Drawing.Point(561, 35);
      this.checkBoxImm.Name = "checkBoxImm";
      this.checkBoxImm.Size = new System.Drawing.Size(170, 17);
      this.checkBoxImm.TabIndex = 4;
      this.checkBoxImm.Text = "&Check to set caret immediately";
      this.checkBoxImm.UseVisualStyleBackColor = true;
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(740, 488);
      this.Controls.Add(this.checkBoxImm);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.textBox1);
      this.Controls.Add(this.htmlEditor1);
      this.Controls.Add(this.menuStrip1);
      this.MainMenuStrip = this.menuStrip1;
      this.Name = "MainForm";
      this.Text = "Form1";
      this.menuStrip1.ResumeLayout(false);
      this.menuStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private Netrix.HtmlEditor htmlEditor1;
        private Netrix.HelpLine.HelpLine helpLine1;
        private Netrix.SpellChecker.Speller speller2;
        private Netrix.SpellChecker.Speller speller1;
        private System.Windows.Forms.ToolStripMenuItem issuesTestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadMailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertHTMLAtIDToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBoxImm;
    }
}

