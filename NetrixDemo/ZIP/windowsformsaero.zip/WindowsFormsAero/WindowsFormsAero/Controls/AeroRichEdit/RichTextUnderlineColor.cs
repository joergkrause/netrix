﻿using System;

namespace WindowsFormsAero
{
    [Serializable]
    public enum RichTextUnderlineColor
    {
        Blue = 1 << 4,
        Red = 5 << 4,
    }
}
