﻿using System;

namespace WindowsFormsAero.InteropServices
{
    [Serializable]
    internal enum WindowsHookType
    {
        KeyboardLowLevel = 13,
        MouseLowLevel = 14,
    }
}
