﻿namespace WindowsFormsAero.Demo
{
    partial class GlassForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            //this.glassProvider1 = new WindowsFormsAero.GlassProvider();
            this.SuspendLayout();
            // 
            // GlassForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 303);
           //this.glassProvider1.SetGlassPadding(this, new System.Windows.Forms.Padding(-1));
            this.Name = "GlassForm";
            this.Text = "GlassForm";
            this.ResumeLayout(false);

        }

        #endregion

        //private GlassProvider glassProvider1;
    }
}