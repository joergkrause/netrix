namespace DockSample
{
    partial class DummySolutionExplorer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Solution \'WinFormsUI\' (2 projects)");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("System", 6, 6);
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("System.Data", 6, 6);
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("System.Drawing", 6, 6);
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("System.Windows.Forms", 6, 6);
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("System.XML", 6, 6);
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("WeifenLuo.WinFormsUI.Docking", 6, 6);
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("References", 4, 4, new System.Windows.Forms.TreeNode[] {
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("BlankIcon.ico", 5, 5);
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("CSProject.ico", 5, 5);
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("OutputWindow.ico", 5, 5);
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("References.ico", 5, 5);
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("SolutionExplorer.ico", 5, 5);
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("TaskListWindow.ico", 5, 5);
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("ToolboxWindow.ico", 5, 5);
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Images", 2, 1, new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode10,
            treeNode11,
            treeNode12,
            treeNode13,
            treeNode14,
            treeNode15});
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("AboutDialog.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("App.ico", 5, 5);
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("AssemblyInfo.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("DummyOutputWindow.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("DummyPropertyWindow.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("DummySolutionExplorer.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("DummyTaskList.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("DummyToolbox.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("MianForm.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Options.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("OptionsDialog.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("DockSample", 3, 3, new System.Windows.Forms.TreeNode[] {
            treeNode8,
            treeNode16,
            treeNode17,
            treeNode18,
            treeNode19,
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode23,
            treeNode24,
            treeNode25,
            treeNode26,
            treeNode27});
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("System", 6, 6);
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("System.Data", 6, 6);
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("System.Design", 6, 6);
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("System.Drawing", 6, 6);
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("System.Windows.Forms", 6, 6);
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("System.XML", 6, 6);
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("References", 4, 4, new System.Windows.Forms.TreeNode[] {
            treeNode29,
            treeNode30,
            treeNode31,
            treeNode32,
            treeNode33,
            treeNode34});
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("DockWindow.AutoHideNo.bmp", 9, 9);
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("DockWindow.AutoHideYes.bmp", 9, 9);
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("DockWindow.Close.bmp", 9, 9);
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("DocumentWindow.Close.bmp", 9, 9);
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("DocumentWindow.ScrollLeftDisabled.bmp", 9, 9);
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("DocumentWindow.ScrollLeftEnabled.bmp", 9, 9);
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("DocumentWindow.ScrollRightDisabled.bmp", 9, 9);
            System.Windows.Forms.TreeNode treeNode43 = new System.Windows.Forms.TreeNode("DocumentWindow.ScrollRightEnabled.bmp", 9, 9);
            System.Windows.Forms.TreeNode treeNode44 = new System.Windows.Forms.TreeNode("Resources", 2, 1, new System.Windows.Forms.TreeNode[] {
            treeNode36,
            treeNode37,
            treeNode38,
            treeNode39,
            treeNode40,
            treeNode41,
            treeNode42,
            treeNode43});
            System.Windows.Forms.TreeNode treeNode45 = new System.Windows.Forms.TreeNode("Enums.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode46 = new System.Windows.Forms.TreeNode("Gdi32.cs", 7, 3);
            System.Windows.Forms.TreeNode treeNode47 = new System.Windows.Forms.TreeNode("Structs.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode48 = new System.Windows.Forms.TreeNode("User32.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode49 = new System.Windows.Forms.TreeNode("Win32", 2, 1, new System.Windows.Forms.TreeNode[] {
            treeNode45,
            treeNode46,
            treeNode47,
            treeNode48});
            System.Windows.Forms.TreeNode treeNode50 = new System.Windows.Forms.TreeNode("AssemblyInfo.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode51 = new System.Windows.Forms.TreeNode("Content.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode52 = new System.Windows.Forms.TreeNode("CotentCollection.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode53 = new System.Windows.Forms.TreeNode("CotentWindowCollection.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode54 = new System.Windows.Forms.TreeNode("DockHelper.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode55 = new System.Windows.Forms.TreeNode("DragHandler.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode56 = new System.Windows.Forms.TreeNode("DragHandlerBase.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode57 = new System.Windows.Forms.TreeNode("FloatWindow.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode58 = new System.Windows.Forms.TreeNode("HiddenMdiChild.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode59 = new System.Windows.Forms.TreeNode("InertButton.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode60 = new System.Windows.Forms.TreeNode("Measures.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode61 = new System.Windows.Forms.TreeNode("NormalTabStripWindow.cs", 8, 8);
            System.Windows.Forms.TreeNode treeNode62 = new System.Windows.Forms.TreeNode("ResourceHelper.cs", 7, 7);
            System.Windows.Forms.TreeNode treeNode63 = new System.Windows.Forms.TreeNode("WeifenLuo.WinFormsUI.Docking", 3, 3, new System.Windows.Forms.TreeNode[] {
            treeNode35,
            treeNode44,
            treeNode49,
            treeNode50,
            treeNode51,
            treeNode52,
            treeNode53,
            treeNode54,
            treeNode55,
            treeNode56,
            treeNode57,
            treeNode58,
            treeNode59,
            treeNode60,
            treeNode61,
            treeNode62});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DummySolutionExplorer));
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Indent = 19;
            this.treeView1.Location = new System.Drawing.Point(0, 24);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "";
            treeNode1.Text = "Solution \'WinFormsUI\' (2 projects)";
            treeNode2.ImageIndex = 6;
            treeNode2.Name = "";
            treeNode2.SelectedImageIndex = 6;
            treeNode2.Text = "System";
            treeNode3.ImageIndex = 6;
            treeNode3.Name = "";
            treeNode3.SelectedImageIndex = 6;
            treeNode3.Text = "System.Data";
            treeNode4.ImageIndex = 6;
            treeNode4.Name = "";
            treeNode4.SelectedImageIndex = 6;
            treeNode4.Text = "System.Drawing";
            treeNode5.ImageIndex = 6;
            treeNode5.Name = "";
            treeNode5.SelectedImageIndex = 6;
            treeNode5.Text = "System.Windows.Forms";
            treeNode6.ImageIndex = 6;
            treeNode6.Name = "";
            treeNode6.SelectedImageIndex = 6;
            treeNode6.Text = "System.XML";
            treeNode7.ImageIndex = 6;
            treeNode7.Name = "";
            treeNode7.SelectedImageIndex = 6;
            treeNode7.Text = "WeifenLuo.WinFormsUI.Docking";
            treeNode8.ImageIndex = 4;
            treeNode8.Name = "";
            treeNode8.SelectedImageIndex = 4;
            treeNode8.Text = "References";
            treeNode9.ImageIndex = 5;
            treeNode9.Name = "";
            treeNode9.SelectedImageIndex = 5;
            treeNode9.Text = "BlankIcon.ico";
            treeNode10.ImageIndex = 5;
            treeNode10.Name = "";
            treeNode10.SelectedImageIndex = 5;
            treeNode10.Text = "CSProject.ico";
            treeNode11.ImageIndex = 5;
            treeNode11.Name = "";
            treeNode11.SelectedImageIndex = 5;
            treeNode11.Text = "OutputWindow.ico";
            treeNode12.ImageIndex = 5;
            treeNode12.Name = "";
            treeNode12.SelectedImageIndex = 5;
            treeNode12.Text = "References.ico";
            treeNode13.ImageIndex = 5;
            treeNode13.Name = "";
            treeNode13.SelectedImageIndex = 5;
            treeNode13.Text = "SolutionExplorer.ico";
            treeNode14.ImageIndex = 5;
            treeNode14.Name = "";
            treeNode14.SelectedImageIndex = 5;
            treeNode14.Text = "TaskListWindow.ico";
            treeNode15.ImageIndex = 5;
            treeNode15.Name = "";
            treeNode15.SelectedImageIndex = 5;
            treeNode15.Text = "ToolboxWindow.ico";
            treeNode16.ImageIndex = 2;
            treeNode16.Name = "";
            treeNode16.SelectedImageIndex = 1;
            treeNode16.Text = "Images";
            treeNode17.ImageIndex = 8;
            treeNode17.Name = "";
            treeNode17.SelectedImageIndex = 8;
            treeNode17.Text = "AboutDialog.cs";
            treeNode18.ImageIndex = 5;
            treeNode18.Name = "";
            treeNode18.SelectedImageIndex = 5;
            treeNode18.Text = "App.ico";
            treeNode19.ImageIndex = 7;
            treeNode19.Name = "";
            treeNode19.SelectedImageIndex = 7;
            treeNode19.Text = "AssemblyInfo.cs";
            treeNode20.ImageIndex = 8;
            treeNode20.Name = "";
            treeNode20.SelectedImageIndex = 8;
            treeNode20.Text = "DummyOutputWindow.cs";
            treeNode21.ImageIndex = 8;
            treeNode21.Name = "";
            treeNode21.SelectedImageIndex = 8;
            treeNode21.Text = "DummyPropertyWindow.cs";
            treeNode22.ImageIndex = 8;
            treeNode22.Name = "";
            treeNode22.SelectedImageIndex = 8;
            treeNode22.Text = "DummySolutionExplorer.cs";
            treeNode23.ImageIndex = 8;
            treeNode23.Name = "";
            treeNode23.SelectedImageIndex = 8;
            treeNode23.Text = "DummyTaskList.cs";
            treeNode24.ImageIndex = 8;
            treeNode24.Name = "";
            treeNode24.SelectedImageIndex = 8;
            treeNode24.Text = "DummyToolbox.cs";
            treeNode25.ImageIndex = 8;
            treeNode25.Name = "";
            treeNode25.SelectedImageIndex = 8;
            treeNode25.Text = "MianForm.cs";
            treeNode26.ImageIndex = 7;
            treeNode26.Name = "";
            treeNode26.SelectedImageIndex = 7;
            treeNode26.Text = "Options.cs";
            treeNode27.ImageIndex = 8;
            treeNode27.Name = "";
            treeNode27.SelectedImageIndex = 8;
            treeNode27.Text = "OptionsDialog.cs";
            treeNode28.ImageIndex = 3;
            treeNode28.Name = "";
            treeNode28.SelectedImageIndex = 3;
            treeNode28.Text = "DockSample";
            treeNode29.ImageIndex = 6;
            treeNode29.Name = "";
            treeNode29.SelectedImageIndex = 6;
            treeNode29.Text = "System";
            treeNode30.ImageIndex = 6;
            treeNode30.Name = "";
            treeNode30.SelectedImageIndex = 6;
            treeNode30.Text = "System.Data";
            treeNode31.ImageIndex = 6;
            treeNode31.Name = "";
            treeNode31.SelectedImageIndex = 6;
            treeNode31.Text = "System.Design";
            treeNode32.ImageIndex = 6;
            treeNode32.Name = "";
            treeNode32.SelectedImageIndex = 6;
            treeNode32.Text = "System.Drawing";
            treeNode33.ImageIndex = 6;
            treeNode33.Name = "";
            treeNode33.SelectedImageIndex = 6;
            treeNode33.Text = "System.Windows.Forms";
            treeNode34.ImageIndex = 6;
            treeNode34.Name = "";
            treeNode34.SelectedImageIndex = 6;
            treeNode34.Text = "System.XML";
            treeNode35.ImageIndex = 4;
            treeNode35.Name = "";
            treeNode35.SelectedImageIndex = 4;
            treeNode35.Text = "References";
            treeNode36.ImageIndex = 9;
            treeNode36.Name = "";
            treeNode36.SelectedImageIndex = 9;
            treeNode36.Text = "DockWindow.AutoHideNo.bmp";
            treeNode37.ImageIndex = 9;
            treeNode37.Name = "";
            treeNode37.SelectedImageIndex = 9;
            treeNode37.Text = "DockWindow.AutoHideYes.bmp";
            treeNode38.ImageIndex = 9;
            treeNode38.Name = "";
            treeNode38.SelectedImageIndex = 9;
            treeNode38.Text = "DockWindow.Close.bmp";
            treeNode39.ImageIndex = 9;
            treeNode39.Name = "";
            treeNode39.SelectedImageIndex = 9;
            treeNode39.Text = "DocumentWindow.Close.bmp";
            treeNode40.ImageIndex = 9;
            treeNode40.Name = "";
            treeNode40.SelectedImageIndex = 9;
            treeNode40.Text = "DocumentWindow.ScrollLeftDisabled.bmp";
            treeNode41.ImageIndex = 9;
            treeNode41.Name = "";
            treeNode41.SelectedImageIndex = 9;
            treeNode41.Text = "DocumentWindow.ScrollLeftEnabled.bmp";
            treeNode42.ImageIndex = 9;
            treeNode42.Name = "";
            treeNode42.SelectedImageIndex = 9;
            treeNode42.Text = "DocumentWindow.ScrollRightDisabled.bmp";
            treeNode43.ImageIndex = 9;
            treeNode43.Name = "";
            treeNode43.SelectedImageIndex = 9;
            treeNode43.Text = "DocumentWindow.ScrollRightEnabled.bmp";
            treeNode44.ImageIndex = 2;
            treeNode44.Name = "";
            treeNode44.SelectedImageIndex = 1;
            treeNode44.Text = "Resources";
            treeNode45.ImageIndex = 7;
            treeNode45.Name = "";
            treeNode45.SelectedImageIndex = 7;
            treeNode45.Text = "Enums.cs";
            treeNode46.ImageIndex = 7;
            treeNode46.Name = "";
            treeNode46.SelectedImageIndex = 3;
            treeNode46.Text = "Gdi32.cs";
            treeNode47.ImageIndex = 7;
            treeNode47.Name = "";
            treeNode47.SelectedImageIndex = 7;
            treeNode47.Text = "Structs.cs";
            treeNode48.ImageIndex = 7;
            treeNode48.Name = "";
            treeNode48.SelectedImageIndex = 7;
            treeNode48.Text = "User32.cs";
            treeNode49.ImageIndex = 2;
            treeNode49.Name = "";
            treeNode49.SelectedImageIndex = 1;
            treeNode49.Text = "Win32";
            treeNode50.ImageIndex = 7;
            treeNode50.Name = "";
            treeNode50.SelectedImageIndex = 7;
            treeNode50.Text = "AssemblyInfo.cs";
            treeNode51.ImageIndex = 8;
            treeNode51.Name = "";
            treeNode51.SelectedImageIndex = 8;
            treeNode51.Text = "Content.cs";
            treeNode52.ImageIndex = 7;
            treeNode52.Name = "";
            treeNode52.SelectedImageIndex = 7;
            treeNode52.Text = "CotentCollection.cs";
            treeNode53.ImageIndex = 7;
            treeNode53.Name = "";
            treeNode53.SelectedImageIndex = 7;
            treeNode53.Text = "CotentWindowCollection.cs";
            treeNode54.ImageIndex = 7;
            treeNode54.Name = "";
            treeNode54.SelectedImageIndex = 7;
            treeNode54.Text = "DockHelper.cs";
            treeNode55.ImageIndex = 7;
            treeNode55.Name = "";
            treeNode55.SelectedImageIndex = 7;
            treeNode55.Text = "DragHandler.cs";
            treeNode56.ImageIndex = 7;
            treeNode56.Name = "";
            treeNode56.SelectedImageIndex = 7;
            treeNode56.Text = "DragHandlerBase.cs";
            treeNode57.ImageIndex = 8;
            treeNode57.Name = "";
            treeNode57.SelectedImageIndex = 8;
            treeNode57.Text = "FloatWindow.cs";
            treeNode58.ImageIndex = 8;
            treeNode58.Name = "";
            treeNode58.SelectedImageIndex = 8;
            treeNode58.Text = "HiddenMdiChild.cs";
            treeNode59.ImageIndex = 7;
            treeNode59.Name = "";
            treeNode59.SelectedImageIndex = 7;
            treeNode59.Text = "InertButton.cs";
            treeNode60.ImageIndex = 7;
            treeNode60.Name = "";
            treeNode60.SelectedImageIndex = 7;
            treeNode60.Text = "Measures.cs";
            treeNode61.ImageIndex = 8;
            treeNode61.Name = "";
            treeNode61.SelectedImageIndex = 8;
            treeNode61.Text = "NormalTabStripWindow.cs";
            treeNode62.ImageIndex = 7;
            treeNode62.Name = "";
            treeNode62.SelectedImageIndex = 7;
            treeNode62.Text = "ResourceHelper.cs";
            treeNode63.ImageIndex = 3;
            treeNode63.Name = "";
            treeNode63.SelectedImageIndex = 3;
            treeNode63.Text = "WeifenLuo.WinFormsUI.Docking";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode28,
            treeNode63});
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(245, 297);
            this.treeView1.TabIndex = 0;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "");
            this.imageList1.Images.SetKeyName(1, "");
            this.imageList1.Images.SetKeyName(2, "");
            this.imageList1.Images.SetKeyName(3, "");
            this.imageList1.Images.SetKeyName(4, "");
            this.imageList1.Images.SetKeyName(5, "");
            this.imageList1.Images.SetKeyName(6, "");
            this.imageList1.Images.SetKeyName(7, "");
            this.imageList1.Images.SetKeyName(8, "");
            this.imageList1.Images.SetKeyName(9, "");
            // 
            // DummySolutionExplorer
            // 
            this.ClientSize = new System.Drawing.Size(245, 322);
            this.Controls.Add(this.treeView1);
            this.DockAreas = ((WeifenLuo.WinFormsUI.Docking.DockAreas)((((WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft | WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight)
                        | WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop)
                        | WeifenLuo.WinFormsUI.Docking.DockAreas.DockBottom)));
            this.HideOnClose = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "DummySolutionExplorer";
            this.Padding = new System.Windows.Forms.Padding(0, 24, 0, 1);
            this.ShowHint = WeifenLuo.WinFormsUI.Docking.DockState.DockRight;
            this.TabText = "Solution Explorer";
            this.Text = "Solution Explorer - WinFormsUI";
            this.ResumeLayout(false);

		}
		#endregion

        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList1;
    }
}