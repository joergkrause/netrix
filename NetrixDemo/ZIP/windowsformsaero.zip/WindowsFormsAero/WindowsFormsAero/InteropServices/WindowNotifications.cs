﻿using System;

namespace WindowsFormsAero.InteropServices
{
    internal static class WindowNotifications
    {
        internal const uint EN_PROTECTED = 0x0704;
    }
}
