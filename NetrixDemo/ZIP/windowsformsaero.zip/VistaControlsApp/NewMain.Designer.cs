namespace VistaControlsApp
{
    partial class NewMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NewMain));
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Node1");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Node2");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Node0");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Node16");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Node17");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Node14", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Node15");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Node12", new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode6,
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Node2", new System.Windows.Forms.TreeNode[] {
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Node37");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Node36", new System.Windows.Forms.TreeNode[] {
            treeNode10});
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Node35", new System.Windows.Forms.TreeNode[] {
            treeNode11});
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Node33", new System.Windows.Forms.TreeNode[] {
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Node32", new System.Windows.Forms.TreeNode[] {
            treeNode13});
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Node11", new System.Windows.Forms.TreeNode[] {
            treeNode14});
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Node8", new System.Windows.Forms.TreeNode[] {
            treeNode15});
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Node34");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Node9", new System.Windows.Forms.TreeNode[] {
            treeNode17});
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Node10");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Node3", new System.Windows.Forms.TreeNode[] {
            treeNode16,
            treeNode18,
            treeNode19});
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Node4");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Node29");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Node41");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Node40", new System.Windows.Forms.TreeNode[] {
            treeNode23});
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Node39", new System.Windows.Forms.TreeNode[] {
            treeNode24});
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Node38", new System.Windows.Forms.TreeNode[] {
            treeNode25});
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Node30", new System.Windows.Forms.TreeNode[] {
            treeNode26});
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Node31");
            System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Node27", new System.Windows.Forms.TreeNode[] {
            treeNode22,
            treeNode27,
            treeNode28});
            System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Node26", new System.Windows.Forms.TreeNode[] {
            treeNode29});
            System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Node5", new System.Windows.Forms.TreeNode[] {
            treeNode30});
            System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Node25");
            System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Node23", new System.Windows.Forms.TreeNode[] {
            treeNode32});
            System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Node24");
            System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Node21", new System.Windows.Forms.TreeNode[] {
            treeNode33,
            treeNode34});
            System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Node22");
            System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("Node28");
            System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Node18", new System.Windows.Forms.TreeNode[] {
            treeNode35,
            treeNode36,
            treeNode37});
            System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Node19");
            System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("Node20");
            System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Node6", new System.Windows.Forms.TreeNode[] {
            treeNode38,
            treeNode39,
            treeNode40});
            System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("Node7");
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("Item 1", 0);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("Item 2", 4);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("Item 3", 10);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("Item 4", 2);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("Item 5", 3);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.themedLabel2 = new VistaControls.ThemeText.ThemedLabel();
            this.themedLabel1 = new VistaControls.ThemeText.ThemedLabel();
            this.searchTextBox1 = new VistaControls.SearchTextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.button1 = new VistaControls.Button();
            this.splitButton1 = new VistaControls.SplitButton();
            this.contextMenu1 = new System.Windows.Forms.ContextMenu();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.commandLink1 = new VistaControls.CommandLink();
            this.commandLink2 = new VistaControls.CommandLink();
            this.commandLink3 = new VistaControls.CommandLink();
            this.commandLink4 = new VistaControls.CommandLink();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.progressBar1 = new VistaControls.ProgressBar();
            this.progressBar2 = new VistaControls.ProgressBar();
            this.progressBar3 = new VistaControls.ProgressBar();
            this.progressBar4 = new VistaControls.ProgressBar();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox1 = new VistaControls.TextBox();
            this.textBox2 = new VistaControls.TextBox();
            this.comboBox1 = new VistaControls.ComboBox();
            this.searchTextBox2 = new VistaControls.SearchTextBox();
            this.treeView1 = new VistaControls.TreeView();
            this.listView1 = new VistaControls.ListView();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.thumbnailViewer1 = new VistaControls.Dwm.ThumbnailViewer();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.flowLayoutPanel3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "audiosrv.dll_I00cb_0409.png");
            this.imageList1.Images.SetKeyName(1, "ActiveContentWizard.ico");
            this.imageList1.Images.SetKeyName(2, "feedback.ico");
            this.imageList1.Images.SetKeyName(3, "imageres.15.ico");
            this.imageList1.Images.SetKeyName(4, "imageres.13.ico");
            this.imageList1.Images.SetKeyName(5, "accessibilitycpl.dll_I0146_0409.png");
            this.imageList1.Images.SetKeyName(6, "bthprops.cpl_I0097_0409.png");
            this.imageList1.Images.SetKeyName(7, "accessibilitycpl.dll_I0144_0409.png");
            this.imageList1.Images.SetKeyName(8, "digitalx.exe_I0065_0409.png");
            this.imageList1.Images.SetKeyName(9, "hdwwiz.exe_I05dd_0409.png");
            this.imageList1.Images.SetKeyName(10, "setup_wm.exe_I0046_0409.png");
            // 
            // themedLabel2
            // 
            this.themedLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.themedLabel2.Cursor = System.Windows.Forms.Cursors.Default;
            this.themedLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.themedLabel2.Location = new System.Drawing.Point(268, 396);
            this.themedLabel2.Name = "themedLabel2";
            this.themedLabel2.Padding = new System.Windows.Forms.Padding(0, 0, 6, 6);
            this.themedLabel2.Size = new System.Drawing.Size(331, 23);
            this.themedLabel2.TabIndex = 26;
            this.themedLabel2.Text = "Welcome!";
            this.themedLabel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.themedLabel2.TextAlignVertical = System.Windows.Forms.VisualStyles.VerticalAlignment.Bottom;
            // 
            // themedLabel1
            // 
            this.themedLabel1.BackColor = System.Drawing.SystemColors.Control;
            this.themedLabel1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.themedLabel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.themedLabel1.Location = new System.Drawing.Point(0, 0);
            this.themedLabel1.Name = "themedLabel1";
            this.themedLabel1.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.themedLabel1.ShadowType = VistaControls.ThemeText.Options.ShadowOption.ShadowType.Single;
            this.themedLabel1.Size = new System.Drawing.Size(365, 58);
            this.themedLabel1.TabIndex = 25;
            this.themedLabel1.Text = "Vista Controls for .NET 2.0";
            this.themedLabel1.TextAlignVertical = System.Windows.Forms.VisualStyles.VerticalAlignment.Center;
            // 
            // searchTextBox1
            // 
            this.searchTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.searchTextBox1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.searchTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.searchTextBox1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.searchTextBox1.InactiveFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchTextBox1.InactiveText = "Search tabs...";
            this.searchTextBox1.Location = new System.Drawing.Point(389, 62);
            this.searchTextBox1.Name = "searchTextBox1";
            this.searchTextBox1.SearchTimer = 600;
            this.searchTextBox1.Size = new System.Drawing.Size(196, 20);
            this.searchTextBox1.StartSearchOnEnter = true;
            this.searchTextBox1.TabIndex = 1;
            this.searchTextBox1.SearchStarted += new System.EventHandler(this.Search);
            this.searchTextBox1.SearchCancelled += new System.EventHandler(this.Search_cancelled);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(12, 66);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(575, 313);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.flowLayoutPanel1);
            this.tabPage1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(567, 287);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Buttons";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.button1);
            this.flowLayoutPanel1.Controls.Add(this.splitButton1);
            this.flowLayoutPanel1.Controls.Add(this.commandLink1);
            this.flowLayoutPanel1.Controls.Add(this.commandLink2);
            this.flowLayoutPanel1.Controls.Add(this.commandLink3);
            this.flowLayoutPanel1.Controls.Add(this.commandLink4);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(561, 281);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.ShowShield = true;
            this.button1.Size = new System.Drawing.Size(122, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Shield Button";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // splitButton1
            // 
            this.splitButton1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.splitButton1.Location = new System.Drawing.Point(3, 32);
            this.splitButton1.Name = "splitButton1";
            this.splitButton1.Size = new System.Drawing.Size(122, 23);
            this.splitButton1.SplitMenu = this.contextMenu1;
            this.splitButton1.TabIndex = 1;
            this.splitButton1.Text = "Split";
            this.splitButton1.UseVisualStyleBackColor = true;
            // 
            // contextMenu1
            // 
            this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem3,
            this.menuItem1,
            this.menuItem2});
            // 
            // menuItem3
            // 
            this.menuItem3.Index = 0;
            this.menuItem3.Text = "Automatic";
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 1;
            this.menuItem1.Text = "Context";
            // 
            // menuItem2
            // 
            this.menuItem2.Index = 2;
            this.menuItem2.Text = "Menu";
            // 
            // commandLink1
            // 
            this.commandLink1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.commandLink1.Location = new System.Drawing.Point(3, 61);
            this.commandLink1.Name = "commandLink1";
            this.commandLink1.Note = "Note.";
            this.commandLink1.Size = new System.Drawing.Size(207, 60);
            this.commandLink1.TabIndex = 2;
            this.commandLink1.Text = "Command Link";
            this.commandLink1.UseVisualStyleBackColor = true;
            this.commandLink1.Click += new System.EventHandler(this.commandLink1_Click);
            // 
            // commandLink2
            // 
            this.commandLink2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.commandLink2.Location = new System.Drawing.Point(3, 127);
            this.commandLink2.Name = "commandLink2";
            this.commandLink2.Note = "Note 2.";
            this.commandLink2.ShowShield = true;
            this.commandLink2.Size = new System.Drawing.Size(207, 60);
            this.commandLink2.TabIndex = 3;
            this.commandLink2.Text = "Shield";
            this.commandLink2.UseVisualStyleBackColor = true;
            // 
            // commandLink3
            // 
            this.commandLink3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.commandLink3.Location = new System.Drawing.Point(3, 193);
            this.commandLink3.Name = "commandLink3";
            this.commandLink3.Size = new System.Drawing.Size(234, 62);
            this.commandLink3.TabIndex = 4;
            this.commandLink3.Text = "Show Test Vertical Panel";
            this.commandLink3.UseVisualStyleBackColor = true;
            this.commandLink3.Click += new System.EventHandler(this.commandLink3_Click);
            // 
            // commandLink4
            // 
            this.commandLink4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.commandLink4.Location = new System.Drawing.Point(243, 3);
            this.commandLink4.Name = "commandLink4";
            this.commandLink4.Size = new System.Drawing.Size(261, 61);
            this.commandLink4.TabIndex = 5;
            this.commandLink4.Text = "Show Test Horizontal Panel";
            this.commandLink4.UseVisualStyleBackColor = true;
            this.commandLink4.Click += new System.EventHandler(this.commandLink4_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.flowLayoutPanel2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(567, 287);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Progress bars";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Controls.Add(this.progressBar1);
            this.flowLayoutPanel2.Controls.Add(this.progressBar2);
            this.flowLayoutPanel2.Controls.Add(this.progressBar3);
            this.flowLayoutPanel2.Controls.Add(this.progressBar4);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(561, 281);
            this.flowLayoutPanel2.TabIndex = 0;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(3, 3);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(355, 23);
            this.progressBar1.TabIndex = 0;
            this.progressBar1.Value = 35;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(3, 32);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.ProgressState = VistaControls.ProgressBar.States.Paused;
            this.progressBar2.Size = new System.Drawing.Size(355, 23);
            this.progressBar2.TabIndex = 1;
            this.progressBar2.Value = 50;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(3, 61);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.ProgressState = VistaControls.ProgressBar.States.Error;
            this.progressBar3.Size = new System.Drawing.Size(355, 23);
            this.progressBar3.TabIndex = 2;
            this.progressBar3.Value = 75;
            // 
            // progressBar4
            // 
            this.progressBar4.Location = new System.Drawing.Point(3, 90);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(355, 23);
            this.progressBar4.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar4.TabIndex = 3;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.flowLayoutPanel4);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(567, 287);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Task Dialogs";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.Controls.Add(this.button2);
            this.flowLayoutPanel4.Controls.Add(this.button11);
            this.flowLayoutPanel4.Controls.Add(this.button3);
            this.flowLayoutPanel4.Controls.Add(this.button8);
            this.flowLayoutPanel4.Controls.Add(this.button4);
            this.flowLayoutPanel4.Controls.Add(this.button5);
            this.flowLayoutPanel4.Controls.Add(this.button6);
            this.flowLayoutPanel4.Controls.Add(this.button7);
            this.flowLayoutPanel4.Controls.Add(this.button10);
            this.flowLayoutPanel4.Controls.Add(this.button9);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel4.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(567, 287);
            this.flowLayoutPanel4.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(3, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "Information";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.td_info);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(3, 32);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(112, 23);
            this.button11.TabIndex = 1;
            this.button11.Text = "Warning";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.ts_warning);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(3, 61);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Error";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.td_error);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(3, 90);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(112, 23);
            this.button8.TabIndex = 3;
            this.button8.Text = "Shield";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.td_shield);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(3, 119);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 23);
            this.button4.TabIndex = 4;
            this.button4.Text = "Security Error";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.td_shielderror);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(3, 148);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(112, 23);
            this.button5.TabIndex = 5;
            this.button5.Text = "Security Success";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.td_shieldsuccess);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(3, 177);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(112, 23);
            this.button6.TabIndex = 6;
            this.button6.Text = "Blue shield";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.td_blueshield);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(3, 206);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(112, 23);
            this.button7.TabIndex = 7;
            this.button7.Text = "Gray shield";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.td_grayshield);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(121, 3);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(112, 52);
            this.button10.TabIndex = 8;
            this.button10.Text = "Complex dialog";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.td_complex);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(121, 61);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(112, 52);
            this.button9.TabIndex = 9;
            this.button9.Text = "Progress bar dialog";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.td_progress);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.flowLayoutPanel3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(567, 287);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Data controls";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.AutoScroll = true;
            this.flowLayoutPanel3.Controls.Add(this.textBox1);
            this.flowLayoutPanel3.Controls.Add(this.textBox2);
            this.flowLayoutPanel3.Controls.Add(this.comboBox1);
            this.flowLayoutPanel3.Controls.Add(this.searchTextBox2);
            this.flowLayoutPanel3.Controls.Add(this.treeView1);
            this.flowLayoutPanel3.Controls.Add(this.listView1);
            this.flowLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(561, 281);
            this.flowLayoutPanel3.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.CueBannerText = "Cue banner";
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(196, 22);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.CueBannerText = "Cue banner (w/focus)";
            this.textBox2.Location = new System.Drawing.Point(3, 29);
            this.textBox2.Name = "textBox2";
            this.textBox2.ShowCueFocused = true;
            this.textBox2.Size = new System.Drawing.Size(196, 22);
            this.textBox2.TabIndex = 1;
            // 
            // comboBox1
            // 
            this.comboBox1.CueBannerText = "Cue banner";
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox1.Location = new System.Drawing.Point(3, 55);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(196, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // searchTextBox2
            // 
            this.searchTextBox2.ActiveFont = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchTextBox2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.searchTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchTextBox2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchTextBox2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.searchTextBox2.Location = new System.Drawing.Point(3, 82);
            this.searchTextBox2.Name = "searchTextBox2";
            this.searchTextBox2.Size = new System.Drawing.Size(196, 20);
            this.searchTextBox2.TabIndex = 3;
            // 
            // treeView1
            // 
            this.treeView1.HotTracking = true;
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(205, 3);
            this.treeView1.Name = "treeView1";
            treeNode1.ImageIndex = 10;
            treeNode1.Name = "Node1";
            treeNode1.Text = "Node1";
            treeNode2.ImageIndex = 1;
            treeNode2.Name = "Node2";
            treeNode2.Text = "Node2";
            treeNode3.Name = "Node0";
            treeNode3.Text = "Node0";
            treeNode4.Name = "Node16";
            treeNode4.Text = "Node16";
            treeNode5.Name = "Node17";
            treeNode5.Text = "Node17";
            treeNode6.Name = "Node14";
            treeNode6.Text = "Node14";
            treeNode7.Name = "Node15";
            treeNode7.Text = "Node15";
            treeNode8.Name = "Node12";
            treeNode8.Text = "Node12";
            treeNode9.ImageIndex = 3;
            treeNode9.Name = "Node2";
            treeNode9.Text = "Node2";
            treeNode10.Name = "Node37";
            treeNode10.Text = "Node37";
            treeNode11.ImageIndex = 8;
            treeNode11.Name = "Node36";
            treeNode11.Text = "Node36";
            treeNode12.ImageIndex = 10;
            treeNode12.Name = "Node35";
            treeNode12.Text = "Node35";
            treeNode13.ImageIndex = 4;
            treeNode13.Name = "Node33";
            treeNode13.Text = "Node33";
            treeNode14.ImageIndex = 6;
            treeNode14.Name = "Node32";
            treeNode14.Text = "Node32";
            treeNode15.ImageIndex = 4;
            treeNode15.Name = "Node11";
            treeNode15.Text = "Node11";
            treeNode16.Name = "Node8";
            treeNode16.Text = "Node8";
            treeNode17.Name = "Node34";
            treeNode17.Text = "Node34";
            treeNode18.ImageIndex = 9;
            treeNode18.Name = "Node9";
            treeNode18.Text = "Node9";
            treeNode19.Name = "Node10";
            treeNode19.Text = "Node10";
            treeNode20.ImageIndex = 5;
            treeNode20.Name = "Node3";
            treeNode20.Text = "Node3";
            treeNode21.ImageIndex = 2;
            treeNode21.Name = "Node4";
            treeNode21.Text = "Node4";
            treeNode22.ImageIndex = 1;
            treeNode22.Name = "Node29";
            treeNode22.Text = "Node29";
            treeNode23.Name = "Node41";
            treeNode23.Text = "Node41";
            treeNode24.ImageIndex = 5;
            treeNode24.Name = "Node40";
            treeNode24.Text = "Node40";
            treeNode25.ImageIndex = 6;
            treeNode25.Name = "Node39";
            treeNode25.Text = "Node39";
            treeNode26.ImageIndex = 10;
            treeNode26.Name = "Node38";
            treeNode26.Text = "Node38";
            treeNode27.ImageIndex = 9;
            treeNode27.Name = "Node30";
            treeNode27.Text = "Node30";
            treeNode28.Name = "Node31";
            treeNode28.Text = "Node31";
            treeNode29.ImageIndex = 7;
            treeNode29.Name = "Node27";
            treeNode29.Text = "Node27";
            treeNode30.Name = "Node26";
            treeNode30.Text = "Node26";
            treeNode31.ImageIndex = 3;
            treeNode31.Name = "Node5";
            treeNode31.Text = "Node5";
            treeNode32.ImageIndex = 5;
            treeNode32.Name = "Node25";
            treeNode32.Text = "Node25";
            treeNode33.ImageIndex = 4;
            treeNode33.Name = "Node23";
            treeNode33.Text = "Node23";
            treeNode34.Name = "Node24";
            treeNode34.Text = "Node24";
            treeNode35.ImageIndex = 1;
            treeNode35.Name = "Node21";
            treeNode35.Text = "Node21";
            treeNode36.ImageIndex = 2;
            treeNode36.Name = "Node22";
            treeNode36.Text = "Node22";
            treeNode37.ImageIndex = 7;
            treeNode37.Name = "Node28";
            treeNode37.Text = "Node28";
            treeNode38.Name = "Node18";
            treeNode38.Text = "Node18";
            treeNode39.Name = "Node19";
            treeNode39.Text = "Node19";
            treeNode40.ImageIndex = 10;
            treeNode40.Name = "Node20";
            treeNode40.Text = "Node20";
            treeNode41.ImageIndex = 3;
            treeNode41.Name = "Node6";
            treeNode41.Text = "Node6";
            treeNode42.Name = "Node7";
            treeNode42.Text = "Node7";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode9,
            treeNode20,
            treeNode21,
            treeNode31,
            treeNode41,
            treeNode42});
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.ShowLines = false;
            this.treeView1.Size = new System.Drawing.Size(122, 240);
            this.treeView1.TabIndex = 4;
            // 
            // listView1
            // 
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5});
            this.listView1.LargeImageList = this.imageList2;
            this.listView1.Location = new System.Drawing.Point(333, 3);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(255, 199);
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.TabIndex = 5;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "audiosrv.dll_I00cb_0409.png");
            this.imageList2.Images.SetKeyName(1, "ActiveContentWizard.ico");
            this.imageList2.Images.SetKeyName(2, "feedback.ico");
            this.imageList2.Images.SetKeyName(3, "imageres.15.ico");
            this.imageList2.Images.SetKeyName(4, "imageres.13.ico");
            this.imageList2.Images.SetKeyName(5, "accessibilitycpl.dll_I0146_0409.png");
            this.imageList2.Images.SetKeyName(6, "bthprops.cpl_I0097_0409.png");
            this.imageList2.Images.SetKeyName(7, "accessibilitycpl.dll_I0144_0409.png");
            this.imageList2.Images.SetKeyName(8, "digitalx.exe_I0065_0409.png");
            this.imageList2.Images.SetKeyName(9, "hdwwiz.exe_I05dd_0409.png");
            this.imageList2.Images.SetKeyName(10, "setup_wm.exe_I0046_0409.png");
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.thumbnailViewer1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(567, 287);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "DWM";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // thumbnailViewer1
            // 
            this.thumbnailViewer1.Location = new System.Drawing.Point(6, 6);
            this.thumbnailViewer1.Name = "thumbnailViewer1";
            this.thumbnailViewer1.ScaleSmallerThumbnails = false;
            this.thumbnailViewer1.Size = new System.Drawing.Size(168, 168);
            this.thumbnailViewer1.TabIndex = 0;
            this.thumbnailViewer1.Text = "thumbnailViewer1";
            this.thumbnailViewer1.ThumbnailAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NewMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 419);
            this.Controls.Add(this.searchTextBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.themedLabel2);
            this.Controls.Add(this.themedLabel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HideTitle = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(590, 455);
            this.Name = "NewMain";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Vista Controls";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.flowLayoutPanel4.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.flowLayoutPanel3.ResumeLayout(false);
            this.flowLayoutPanel3.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

		private System.Windows.Forms.ImageList imageList1;
		private VistaControls.ThemeText.ThemedLabel themedLabel1;
		private VistaControls.ThemeText.ThemedLabel themedLabel2;
		private VistaControls.SearchTextBox searchTextBox1;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
		private VistaControls.ProgressBar progressBar1;
		private VistaControls.ProgressBar progressBar2;
		private VistaControls.ProgressBar progressBar3;
		private VistaControls.ProgressBar progressBar4;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
		private VistaControls.TextBox textBox1;
		private VistaControls.ComboBox comboBox1;
		private VistaControls.SearchTextBox searchTextBox2;
		private VistaControls.TreeView treeView1;
		private VistaControls.ListView listView1;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.TabPage tabPage5;
		private VistaControls.TextBox textBox2;
		private System.Windows.Forms.ImageList imageList2;
        private VistaControls.Dwm.ThumbnailViewer thumbnailViewer1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private VistaControls.Button button1;
        private VistaControls.SplitButton splitButton1;
        private VistaControls.CommandLink commandLink1;
        private VistaControls.CommandLink commandLink2;
        private VistaControls.CommandLink commandLink3;
        private VistaControls.CommandLink commandLink4;
    }
}