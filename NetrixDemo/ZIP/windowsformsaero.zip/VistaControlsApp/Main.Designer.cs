namespace VistaControlsApp
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
			System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Node1");
			System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Node2");
			System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Node0");
			System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Node16");
			System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Node17");
			System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Node14", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode5});
			System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Node15");
			System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Node12", new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode6,
            treeNode7});
			System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Node2", new System.Windows.Forms.TreeNode[] {
            treeNode8});
			System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Node37");
			System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Node36", new System.Windows.Forms.TreeNode[] {
            treeNode10});
			System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Node35", new System.Windows.Forms.TreeNode[] {
            treeNode11});
			System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Node33", new System.Windows.Forms.TreeNode[] {
            treeNode12});
			System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Node32", new System.Windows.Forms.TreeNode[] {
            treeNode13});
			System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Node11", new System.Windows.Forms.TreeNode[] {
            treeNode14});
			System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Node8", new System.Windows.Forms.TreeNode[] {
            treeNode15});
			System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Node34");
			System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Node9", new System.Windows.Forms.TreeNode[] {
            treeNode17});
			System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Node10");
			System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Node3", new System.Windows.Forms.TreeNode[] {
            treeNode16,
            treeNode18,
            treeNode19});
			System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Node4");
			System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Node29");
			System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Node41");
			System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Node40", new System.Windows.Forms.TreeNode[] {
            treeNode23});
			System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Node39", new System.Windows.Forms.TreeNode[] {
            treeNode24});
			System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Node38", new System.Windows.Forms.TreeNode[] {
            treeNode25});
			System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("Node30", new System.Windows.Forms.TreeNode[] {
            treeNode26});
			System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("Node31");
			System.Windows.Forms.TreeNode treeNode29 = new System.Windows.Forms.TreeNode("Node27", new System.Windows.Forms.TreeNode[] {
            treeNode22,
            treeNode27,
            treeNode28});
			System.Windows.Forms.TreeNode treeNode30 = new System.Windows.Forms.TreeNode("Node26", new System.Windows.Forms.TreeNode[] {
            treeNode29});
			System.Windows.Forms.TreeNode treeNode31 = new System.Windows.Forms.TreeNode("Node5", new System.Windows.Forms.TreeNode[] {
            treeNode30});
			System.Windows.Forms.TreeNode treeNode32 = new System.Windows.Forms.TreeNode("Node25");
			System.Windows.Forms.TreeNode treeNode33 = new System.Windows.Forms.TreeNode("Node23", new System.Windows.Forms.TreeNode[] {
            treeNode32});
			System.Windows.Forms.TreeNode treeNode34 = new System.Windows.Forms.TreeNode("Node24");
			System.Windows.Forms.TreeNode treeNode35 = new System.Windows.Forms.TreeNode("Node21", new System.Windows.Forms.TreeNode[] {
            treeNode33,
            treeNode34});
			System.Windows.Forms.TreeNode treeNode36 = new System.Windows.Forms.TreeNode("Node22");
			System.Windows.Forms.TreeNode treeNode37 = new System.Windows.Forms.TreeNode("Node28");
			System.Windows.Forms.TreeNode treeNode38 = new System.Windows.Forms.TreeNode("Node18", new System.Windows.Forms.TreeNode[] {
            treeNode35,
            treeNode36,
            treeNode37});
			System.Windows.Forms.TreeNode treeNode39 = new System.Windows.Forms.TreeNode("Node19");
			System.Windows.Forms.TreeNode treeNode40 = new System.Windows.Forms.TreeNode("Node20");
			System.Windows.Forms.TreeNode treeNode41 = new System.Windows.Forms.TreeNode("Node6", new System.Windows.Forms.TreeNode[] {
            treeNode38,
            treeNode39,
            treeNode40});
			System.Windows.Forms.TreeNode treeNode42 = new System.Windows.Forms.TreeNode("Node7");
			System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item1",
            "Text"}, -1);
			System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item2",
            "Sub1"}, -1);
			System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item3",
            "i"}, -1);
			System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item4",
            "u"}, -1);
			System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item5",
            "z"}, -1);
			System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new string[] {
            "Item6",
            "a"}, -1);
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.progressBar1 = new VistaControls.ProgressBar();
			this.progressBar2 = new VistaControls.ProgressBar();
			this.progressBar3 = new VistaControls.ProgressBar();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.button2 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.splitButton1 = new VistaControls.SplitButton();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.themedLabel2 = new VistaControls.ThemeText.ThemedLabel();
			this.themedLabel1 = new VistaControls.ThemeText.ThemedLabel();
			this.treeView1 = new VistaControls.TreeView();
			this.comboBox2 = new VistaControls.ComboBox();
			this.listView2 = new VistaControls.ListView();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.textBox1 = new VistaControls.TextBox();
			this.commandLink2 = new VistaControls.CommandLink();
			this.commandLink1 = new VistaControls.CommandLink();
			this.button1 = new VistaControls.Button();
			this.searchTextBox1 = new VistaControls.SearchTextBox();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.progressBar1);
			this.groupBox1.Controls.Add(this.progressBar2);
			this.groupBox1.Controls.Add(this.progressBar3);
			this.groupBox1.Location = new System.Drawing.Point(198, 75);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(453, 116);
			this.groupBox1.TabIndex = 22;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Progress Bar";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 72);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(46, 13);
			this.label3.TabIndex = 10;
			this.label3.Text = "Paused:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 49);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(32, 13);
			this.label2.TabIndex = 9;
			this.label2.Text = "Error:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 26);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(43, 13);
			this.label1.TabIndex = 8;
			this.label1.Text = "Normal:";
			// 
			// progressBar1
			// 
			this.progressBar1.Location = new System.Drawing.Point(54, 20);
			this.progressBar1.Margin = new System.Windows.Forms.Padding(2);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new System.Drawing.Size(349, 19);
			this.progressBar1.TabIndex = 5;
			this.progressBar1.Value = 50;
			// 
			// progressBar2
			// 
			this.progressBar2.Location = new System.Drawing.Point(54, 43);
			this.progressBar2.Margin = new System.Windows.Forms.Padding(2);
			this.progressBar2.Name = "progressBar2";
			this.progressBar2.ProgressState = VistaControls.ProgressBar.States.Error;
			this.progressBar2.Size = new System.Drawing.Size(349, 19);
			this.progressBar2.TabIndex = 6;
			this.progressBar2.Value = 50;
			// 
			// progressBar3
			// 
			this.progressBar3.Location = new System.Drawing.Point(54, 66);
			this.progressBar3.Margin = new System.Windows.Forms.Padding(2);
			this.progressBar3.Name = "progressBar3";
			this.progressBar3.ProgressState = VistaControls.ProgressBar.States.Paused;
			this.progressBar3.Size = new System.Drawing.Size(349, 19);
			this.progressBar3.TabIndex = 7;
			this.progressBar3.Value = 50;
			// 
			// imageList1
			// 
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			this.imageList1.Images.SetKeyName(0, "audiosrv.dll_I00cb_0409.png");
			this.imageList1.Images.SetKeyName(1, "ActiveContentWizard.ico");
			this.imageList1.Images.SetKeyName(2, "feedback.ico");
			this.imageList1.Images.SetKeyName(3, "imageres.15.ico");
			this.imageList1.Images.SetKeyName(4, "imageres.13.ico");
			this.imageList1.Images.SetKeyName(5, "accessibilitycpl.dll_I0146_0409.png");
			this.imageList1.Images.SetKeyName(6, "bthprops.cpl_I0097_0409.png");
			this.imageList1.Images.SetKeyName(7, "accessibilitycpl.dll_I0144_0409.png");
			this.imageList1.Images.SetKeyName(8, "digitalx.exe_I0065_0409.png");
			this.imageList1.Images.SetKeyName(9, "hdwwiz.exe_I05dd_0409.png");
			this.imageList1.Images.SetKeyName(10, "setup_wm.exe_I0046_0409.png");
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.button2);
			this.groupBox2.Controls.Add(this.button9);
			this.groupBox2.Controls.Add(this.button8);
			this.groupBox2.Controls.Add(this.button7);
			this.groupBox2.Controls.Add(this.button6);
			this.groupBox2.Controls.Add(this.button5);
			this.groupBox2.Controls.Add(this.button4);
			this.groupBox2.Controls.Add(this.button3);
			this.groupBox2.Location = new System.Drawing.Point(476, 221);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(196, 197);
			this.groupBox2.TabIndex = 24;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Task Dialog";
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(18, 20);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(68, 67);
			this.button2.TabIndex = 39;
			this.button2.Text = "Marquee Progress";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.tskDlgMarquee);
			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(18, 94);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(75, 65);
			this.button9.TabIndex = 38;
			this.button9.Text = "Complex TaskDialog";
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new System.EventHandler(this.tskDlgComplex);
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(113, 165);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(75, 23);
			this.button8.TabIndex = 37;
			this.button8.Text = "Shield";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.tskDlg6Click);
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(113, 136);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(75, 23);
			this.button7.TabIndex = 36;
			this.button7.Text = "Information";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.tskDlg5Click);
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(113, 107);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(75, 23);
			this.button6.TabIndex = 35;
			this.button6.Text = "Warning";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.tskDlg4Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(113, 78);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(75, 23);
			this.button5.TabIndex = 34;
			this.button5.Text = "Stop";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.tskDlg3Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(92, 49);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(96, 23);
			this.button4.TabIndex = 33;
			this.button4.Text = "SecuritySuccess";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.tskDlg2Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(92, 20);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(96, 23);
			this.button3.TabIndex = 32;
			this.button3.Text = "SecurityError";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.tskDlg1Click);
			// 
			// splitButton1
			// 
			this.splitButton1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.splitButton1.Location = new System.Drawing.Point(233, 234);
			this.splitButton1.Name = "splitButton1";
			this.splitButton1.Size = new System.Drawing.Size(121, 23);
			this.splitButton1.SplitMenu = this.contextMenu1;
			this.splitButton1.TabIndex = 27;
			this.splitButton1.Text = "Increase";
			this.splitButton1.UseVisualStyleBackColor = true;
			this.splitButton1.SplitMenuOpening += new System.EventHandler<VistaControls.SplitButton.SplitMenuEventArgs>(this.Split_opening);
			this.splitButton1.Click += new System.EventHandler(this.Split_click);
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItem2});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "Increase";
			this.menuItem1.Click += new System.EventHandler(this.SplitMenu_increment);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "Decrease";
			this.menuItem2.Click += new System.EventHandler(this.SplitMenu_decrease);
			// 
			// themedLabel2
			// 
			this.themedLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.themedLabel2.Cursor = System.Windows.Forms.Cursors.Default;
			this.themedLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.themedLabel2.Location = new System.Drawing.Point(45, 430);
			this.themedLabel2.Name = "themedLabel2";
			this.themedLabel2.Padding = new System.Windows.Forms.Padding(0, 0, 6, 6);
			this.themedLabel2.Size = new System.Drawing.Size(637, 23);
			this.themedLabel2.TabIndex = 26;
			this.themedLabel2.Text = "Welcome!";
			this.themedLabel2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.themedLabel2.TextAlignVertical = System.Windows.Forms.VisualStyles.VerticalAlignment.Bottom;
			// 
			// themedLabel1
			// 
			this.themedLabel1.BackColor = System.Drawing.SystemColors.Control;
			this.themedLabel1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.themedLabel1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.themedLabel1.Location = new System.Drawing.Point(0, 0);
			this.themedLabel1.Name = "themedLabel1";
			this.themedLabel1.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
			this.themedLabel1.ShadowType = VistaControls.ThemeText.Options.ShadowOption.ShadowType.Single;
			this.themedLabel1.Size = new System.Drawing.Size(454, 58);
			this.themedLabel1.TabIndex = 25;
			this.themedLabel1.Text = "Vista Controls for .NET 2.0";
			this.themedLabel1.TextAlignVertical = System.Windows.Forms.VisualStyles.VerticalAlignment.Center;
			// 
			// treeView1
			// 
			this.treeView1.HotTracking = true;
			this.treeView1.ImageIndex = 0;
			this.treeView1.ImageList = this.imageList1;
			this.treeView1.Location = new System.Drawing.Point(322, 272);
			this.treeView1.Name = "treeView1";
			treeNode1.ImageIndex = 10;
			treeNode1.Name = "Node1";
			treeNode1.Text = "Node1";
			treeNode2.ImageIndex = 1;
			treeNode2.Name = "Node2";
			treeNode2.Text = "Node2";
			treeNode3.Name = "Node0";
			treeNode3.Text = "Node0";
			treeNode4.Name = "Node16";
			treeNode4.Text = "Node16";
			treeNode5.Name = "Node17";
			treeNode5.Text = "Node17";
			treeNode6.Name = "Node14";
			treeNode6.Text = "Node14";
			treeNode7.Name = "Node15";
			treeNode7.Text = "Node15";
			treeNode8.Name = "Node12";
			treeNode8.Text = "Node12";
			treeNode9.ImageIndex = 3;
			treeNode9.Name = "Node2";
			treeNode9.Text = "Node2";
			treeNode10.Name = "Node37";
			treeNode10.Text = "Node37";
			treeNode11.ImageIndex = 8;
			treeNode11.Name = "Node36";
			treeNode11.Text = "Node36";
			treeNode12.ImageIndex = 10;
			treeNode12.Name = "Node35";
			treeNode12.Text = "Node35";
			treeNode13.ImageIndex = 4;
			treeNode13.Name = "Node33";
			treeNode13.Text = "Node33";
			treeNode14.ImageIndex = 6;
			treeNode14.Name = "Node32";
			treeNode14.Text = "Node32";
			treeNode15.ImageIndex = 4;
			treeNode15.Name = "Node11";
			treeNode15.Text = "Node11";
			treeNode16.Name = "Node8";
			treeNode16.Text = "Node8";
			treeNode17.Name = "Node34";
			treeNode17.Text = "Node34";
			treeNode18.ImageIndex = 9;
			treeNode18.Name = "Node9";
			treeNode18.Text = "Node9";
			treeNode19.Name = "Node10";
			treeNode19.Text = "Node10";
			treeNode20.ImageIndex = 5;
			treeNode20.Name = "Node3";
			treeNode20.Text = "Node3";
			treeNode21.ImageIndex = 2;
			treeNode21.Name = "Node4";
			treeNode21.Text = "Node4";
			treeNode22.ImageIndex = 1;
			treeNode22.Name = "Node29";
			treeNode22.Text = "Node29";
			treeNode23.Name = "Node41";
			treeNode23.Text = "Node41";
			treeNode24.ImageIndex = 5;
			treeNode24.Name = "Node40";
			treeNode24.Text = "Node40";
			treeNode25.ImageIndex = 6;
			treeNode25.Name = "Node39";
			treeNode25.Text = "Node39";
			treeNode26.ImageIndex = 10;
			treeNode26.Name = "Node38";
			treeNode26.Text = "Node38";
			treeNode27.ImageIndex = 9;
			treeNode27.Name = "Node30";
			treeNode27.Text = "Node30";
			treeNode28.Name = "Node31";
			treeNode28.Text = "Node31";
			treeNode29.ImageIndex = 7;
			treeNode29.Name = "Node27";
			treeNode29.Text = "Node27";
			treeNode30.Name = "Node26";
			treeNode30.Text = "Node26";
			treeNode31.ImageIndex = 3;
			treeNode31.Name = "Node5";
			treeNode31.Text = "Node5";
			treeNode32.ImageIndex = 5;
			treeNode32.Name = "Node25";
			treeNode32.Text = "Node25";
			treeNode33.ImageIndex = 4;
			treeNode33.Name = "Node23";
			treeNode33.Text = "Node23";
			treeNode34.Name = "Node24";
			treeNode34.Text = "Node24";
			treeNode35.ImageIndex = 1;
			treeNode35.Name = "Node21";
			treeNode35.Text = "Node21";
			treeNode36.ImageIndex = 2;
			treeNode36.Name = "Node22";
			treeNode36.Text = "Node22";
			treeNode37.ImageIndex = 7;
			treeNode37.Name = "Node28";
			treeNode37.Text = "Node28";
			treeNode38.Name = "Node18";
			treeNode38.Text = "Node18";
			treeNode39.Name = "Node19";
			treeNode39.Text = "Node19";
			treeNode40.ImageIndex = 10;
			treeNode40.Name = "Node20";
			treeNode40.Text = "Node20";
			treeNode41.ImageIndex = 3;
			treeNode41.Name = "Node6";
			treeNode41.Text = "Node6";
			treeNode42.Name = "Node7";
			treeNode42.Text = "Node7";
			this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode9,
            treeNode20,
            treeNode21,
            treeNode31,
            treeNode41,
            treeNode42});
			this.treeView1.SelectedImageIndex = 0;
			this.treeView1.ShowLines = false;
			this.treeView1.Size = new System.Drawing.Size(112, 146);
			this.treeView1.TabIndex = 23;
			// 
			// comboBox2
			// 
			this.comboBox2.CueBannerText = "Select an item";
			this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Items.AddRange(new object[] {
            "One",
            "Two",
            "Three",
            "Four",
            "Five"});
			this.comboBox2.Location = new System.Drawing.Point(233, 201);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(121, 21);
			this.comboBox2.TabIndex = 21;
			// 
			// listView2
			// 
			this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
			this.listView2.FullRowSelect = true;
			this.listView2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6});
			this.listView2.Location = new System.Drawing.Point(18, 285);
			this.listView2.Margin = new System.Windows.Forms.Padding(2);
			this.listView2.Name = "listView2";
			this.listView2.Size = new System.Drawing.Size(260, 133);
			this.listView2.TabIndex = 19;
			this.listView2.UseCompatibleStateImageBehavior = false;
			this.listView2.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Width = 105;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Width = 99;
			// 
			// textBox1
			// 
			this.textBox1.CueBannerText = "Cue Banner Text";
			this.textBox1.Location = new System.Drawing.Point(389, 196);
			this.textBox1.Margin = new System.Windows.Forms.Padding(2);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(283, 20);
			this.textBox1.TabIndex = 9;
			// 
			// commandLink2
			// 
			this.commandLink2.BackColor = System.Drawing.Color.Transparent;
			this.commandLink2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.commandLink2.Location = new System.Drawing.Point(11, 201);
			this.commandLink2.Margin = new System.Windows.Forms.Padding(2);
			this.commandLink2.Name = "commandLink2";
			this.commandLink2.Note = "Other Note";
			this.commandLink2.Size = new System.Drawing.Size(194, 56);
			this.commandLink2.TabIndex = 4;
			this.commandLink2.Text = "commandLink2";
			this.commandLink2.UseVisualStyleBackColor = false;
			this.commandLink2.Click += new System.EventHandler(this.commandLink2_Click);
			// 
			// commandLink1
			// 
			this.commandLink1.BackColor = System.Drawing.Color.Transparent;
			this.commandLink1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.commandLink1.Location = new System.Drawing.Point(11, 141);
			this.commandLink1.Margin = new System.Windows.Forms.Padding(2);
			this.commandLink1.Name = "commandLink1";
			this.commandLink1.Note = "Note";
			this.commandLink1.ShowShield = true;
			this.commandLink1.Size = new System.Drawing.Size(194, 56);
			this.commandLink1.TabIndex = 3;
			this.commandLink1.Text = "commandLink1";
			this.commandLink1.UseVisualStyleBackColor = false;
			this.commandLink1.Click += new System.EventHandler(this.commandLink1_Click);
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button1.Location = new System.Drawing.Point(11, 73);
			this.button1.Margin = new System.Windows.Forms.Padding(2);
			this.button1.Name = "button1";
			this.button1.ShowShield = true;
			this.button1.Size = new System.Drawing.Size(142, 46);
			this.button1.TabIndex = 0;
			this.button1.Text = "ShieldButton";
			this.button1.UseVisualStyleBackColor = true;
			// 
			// searchTextBox1
			// 
			this.searchTextBox1.ActiveFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.searchTextBox1.BackColor = System.Drawing.SystemColors.InactiveBorder;
			this.searchTextBox1.ForeColor = System.Drawing.SystemColors.GrayText;
			this.searchTextBox1.Location = new System.Drawing.Point(476, 12);
			this.searchTextBox1.Name = "searchTextBox1";
			this.searchTextBox1.Size = new System.Drawing.Size(196, 20);
			this.searchTextBox1.TabIndex = 28;
			// 
			// Main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(682, 453);
			this.Controls.Add(this.searchTextBox1);
			this.Controls.Add(this.splitButton1);
			this.Controls.Add(this.themedLabel2);
			this.Controls.Add(this.themedLabel1);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.treeView1);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.comboBox2);
			this.Controls.Add(this.listView2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.commandLink2);
			this.Controls.Add(this.commandLink1);
			this.Controls.Add(this.button1);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.MaximizeBox = false;
			this.MinimumSize = new System.Drawing.Size(698, 489);
			this.Name = "Main";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "Vista Controls";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private VistaControls.Button button1;
        private VistaControls.CommandLink commandLink1;
        private VistaControls.CommandLink commandLink2;
        private VistaControls.ProgressBar progressBar1;
        private VistaControls.ProgressBar progressBar2;
        private VistaControls.ProgressBar progressBar3;
        private VistaControls.TextBox textBox1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private VistaControls.ComboBox comboBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private VistaControls.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList1;
        private VistaControls.ListView listView2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button3;
		private VistaControls.ThemeText.ThemedLabel themedLabel1;
		private VistaControls.ThemeText.ThemedLabel themedLabel2;
		private VistaControls.SplitButton splitButton1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private VistaControls.SearchTextBox searchTextBox1;
    }
}