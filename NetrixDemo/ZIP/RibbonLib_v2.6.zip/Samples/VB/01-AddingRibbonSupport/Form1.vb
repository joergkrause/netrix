﻿Imports RibbonLib

Namespace _01_AddingRibbonSupport
	Partial Public Class Form1
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
End Namespace
