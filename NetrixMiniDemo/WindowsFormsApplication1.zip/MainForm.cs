﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GuruComponents.Demo.MiniDemo {
  public partial class MainForm : Form {

    private bool firstTimeLoader = true;

    public MainForm() {
      InitializeComponent();
      htmlEditor1.ReadyStateComplete += htmlEditor1_ReadyStateComplete;
    }

    void htmlEditor1_ReadyStateComplete(object sender, EventArgs e) {
      if (firstTimeLoader) {
        var body = htmlEditor1.GetBodyElement();
        var moreHtml = "<p>&lt;Anrede&gt;</p><p>&nbsp;</p><p id=\"BW2CARET\">&nbsp;</p><p>&nbsp;</p><p></p><p>&nbsp;</p><hr/>";
        body.InsertAdjacentHtml(Netrix.WebEditing.Elements.InsertWhere.AfterBegin, moreHtml);
        if (checkBoxImm.Checked) {
          insertHTMLAtIDToolStripMenuItem_Click(sender, e);
        }        
      }
      firstTimeLoader = true;
    }

    private void insertHTMLAtIDToolStripMenuItem_Click(object sender, EventArgs e) {
      var element = htmlEditor1.GetElementById("BW2CARET");
      if (element != null) {
        htmlEditor1.TextSelector.MovePointersToElement(element, false);
        htmlEditor1.TextSelector.MoveCaretToPointer(true);
        htmlEditor1.ShowCaret();
      }
    }

    private void setCaretToolStripMenuItem_Click(object sender, EventArgs e) {
      var element = htmlEditor1.GetElementById("SETCARET");
      htmlEditor1.Selection.SynchronizeSelection();
      if (element != null) {
        htmlEditor1.TextSelector.ClearRangeStore();
        htmlEditor1.TextSelector.MovePointersToElement(element, false);
        htmlEditor1.Selection.ClearSelection();
        htmlEditor1.TextSelector.MoveCaretToPointer(false);
      }
    }

    private void loadMailToolStripMenuItem_Click(object sender, EventArgs e) {
      var ofd = new OpenFileDialog();
      ofd.Filter = "HTML (*.htm;*.html)|*.html;*.htm|All Files|*.*";
      ofd.InitialDirectory = this.GetType().Assembly.Location;
      if (ofd.ShowDialog() == DialogResult.OK) {
        if (File.Exists(ofd.FileName)) {
          htmlEditor1.LoadFile(ofd.FileName);
        }
      }
    }

    private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
      Close();
    }

    private void newToolStripMenuItem_Click(object sender, EventArgs e) {
      firstTimeLoader = false;
      htmlEditor1.NewDocument();
    }

    private void saveToolStripMenuItem_Click(object sender, EventArgs e) {
      var sfd = new SaveFileDialog();
      sfd.Filter = "HTML (*.htm;*.html)|*.html;*.htm|All Files|*.*";
      sfd.InitialDirectory = this.GetType().Assembly.Location;
      if (sfd.ShowDialog() == DialogResult.OK) {
        htmlEditor1.SaveFile(sfd.FileName);
      }
    }

  }
}
