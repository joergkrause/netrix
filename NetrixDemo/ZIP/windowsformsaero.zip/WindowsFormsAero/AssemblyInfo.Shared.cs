﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyVersion(ThisAssembly.Version)]
[assembly: AssemblyFileVersion(ThisAssembly.Version)]

[assembly: AssemblyProduct(ThisAssembly.Product)]
[assembly: AssemblyCopyright(ThisAssembly.Copyright)]

[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]

[assembly: NeutralResourcesLanguage("en-US")]