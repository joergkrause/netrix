﻿using System;

namespace WindowsFormsAero.InteropServices
{
    [Serializable]
    internal enum OleRender
    {
        None = 0,
        Draw = 1,
        Format = 2,
        AsIs = 3,
    }
}
